package com.test.ejb;

import com.test.intf.DataReplicationWs;
import javax.ejb.Stateless;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author pshankar
 */
@WebService(
        portName          = "DataReplicationPort",
        targetNamespace   = "http://com.test.services/wsdl",
        serviceName       = "DataReplicationBean",
        endpointInterface = "com.test.intf.DataReplicationWs"
        )
@Stateless()
public class DataReplicationBean implements DataReplicationWs
{
    
    /**
     * This is a sample web service operation
     * @param txt
     * @return 
     */
    // @WebMethod(operationName = "hello")
    @Override
    public String hello(@WebParam(name = "name") String txt) 
    {
        return "Hello " + txt + " !";
    }
    
    public String defMethod( @WebParam(name = "") String txt)
    {
       return "No Such method" ;
    }
}
